#ifndef ALGORITHMES_H_INCLUDED
#define ALGORITHMES_H_INCLUDED
#define MAX 100
typedef TAB100[MAX];
int dichotomie(TAB100 t,int n,int x)
{
    int e=0;int min=0;int max=n-1;int milieu;
    if((x==t[0]) || (x==t[n-1]))
        e=1;
    while ((!e)&&(min<=max)){
        milieu=(max+min)/2;
         if(x==t[milieu])
            e=1;
         else
         {
             if(x<t[milieu])
                max=milieu -1;
             else
                min=milieu+1;
         }
    }
    return e;
}
void insertion(TAB100 t,int *n,int x)
{
    int i;
    for(i=*n-1;i>=0 && t[i]>x;i--){
        t[i+1]=t[i];

    }
    t[i+1]=x;
    (*n)++;

}
void fusion(TAB100 t1,int n1,TAB100 t2,int *n2)
{
    int i;
    for(i=0;i<n1;i++){
        insertion(t2,n2,t1[i]);

    }
}
void tri_selec(TAB100 t,int n)
{
    int i,j;
    for(i=0;i<n-1;i++){
        int min=i;
        for(j=i+1;j<n;j++)
        {
            if(t[j]<t[min]){
                min=j;
            }
        }
        permuter (&t[min],&t[i]);
    }

}
void tri_insertion(TAB100 t,int n)
{
    int i,j,x;
    for(i=0;i<n;i++){
        x=t[i];
        j=i-1;
        while(j>=0 && t[j]>x){
            t[j+1]=t[j];
            j--;
        }

    t[j+1]=x;
    }
}
void tri_rapide(TAB100 t,int first,int last)
{
    int i,j,k;
    i=first;j=last;k=t[(first+last)/2];
    do{
        int tempon;
        while(t[i]<k)
            i++;
        while(t[j]>k)
            j--;
        {
            permuter(&t[i],&t[j]);
            j--;
            i++;
        }
    }while(i<j);
    if(first<j)
        tri_rapide(t,first,j);
    if(last>i)
        tri_rapide(t,i,last);

}



#endif // ALGORITHMES_H_INCLUDED
