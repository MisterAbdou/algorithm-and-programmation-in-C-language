#include "algorithmes.h"
#include "utilitaires.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include<windows.h>

int main()
{
    menu_pricipal();
   Sleep(10000);
}
