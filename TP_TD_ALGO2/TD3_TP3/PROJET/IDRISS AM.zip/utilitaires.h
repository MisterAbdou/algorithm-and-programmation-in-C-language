#ifndef UTILITAIRES_H_INCLUDED
#define UTILITAIRES_H_INCLUDED
void saisie(TAB100 t,int n)
{
    int i;
    for(i=0;i<=n-1;i++)
     {
         printf("t[%d]=",i);
         scanf("%d",&t[i]);
     }
}
 void affichage(TAB100 t,int n)
 {
     int i;
     for(i=0;i<=n-1;i++)
        printf("%d\t",t[i]);
     printf("\n\n");
 }
void permuter( int *a,int *b)
{
    int temp;
    temp=*a;
    *a=*b;
    *b=temp;
}
void sous_menu1(TAB100 t,int taille,int x, TAB100 t1,TAB100 t2,int n1, int n2){
    char choix;
    printf("\\recherche_insertion_fusion\n");
    printf("\\===========================\n");
    printf("R.recherche dichotomie\n");
    printf("I.insertion d'un element\n");
    printf("U.fusion de deux tableaux\n");
    printf("F.fIN\n");
    printf("=========================\n\n");
    printf("FAIES VOTRE CHOIX[R_I_U_F]:");
    scanf(" %c",&choix);
    if(choix=tolower(choix))
        choix=toupper(choix);
    switch(choix){
  case 'R':
    printf("donner la taille du tableau:");
    scanf("%d",&taille);
    saisie(t,taille);
    printf("recherche dichotomie d'un element dans un tableau\n");
    printf("donner l'entier a recherche:");
    scanf("%d",&x);
    if(dichotomie(t,taille,x)==1)
     printf("%d est dans le tableau\n\n",x);
    else
        printf("%d n'est pas dans le tableau\n\n",x);
    break;
  case 'I':
    printf("donner le nombre d'element du tableau:\n");
    scanf("%d",&taille);
    saisie(t,taille);
    tri_insertion(t,taille);
    affichage(t,taille);
    printf("insertion un element dans un tableau\n\n");
    printf("====================================\n");
    printf("donner un element a inserer:\n");
    scanf("%d",&x);
    insertion(t,&taille,x);
    affichage(t,taille);
    break;
  case 'U':
      printf("donner le nombre d'element du tableau 1:\n");
      scanf("%d",&n1);
      printf("donner le nombre d'element du tableau 2:\n");
      scanf("%d",&n2);
      printf("\nremplir t1\n");
      saisie(t1,n1);
      tri_selec(t1,n1);
      printf("\nremplir t2\n");
      saisie(t2,n2);
      tri_selec(t2,n2);
      fusion(t1,n1,t2,&n2);
      printf("\nfusion de t1 et t2:\n");
      affichage(t2,n2);
      break;
  case 'F':
      break;
  default:
     printf("mauvais choix, reprenez SVP:\n\n");
     break;
    }
}
void sous_menu2(TAB100 t,int n)
{
    char choix;
    printf("algorithmes de tri:\n");
    printf("====================\n");
    printf("S.tri par selection\n");
    printf("I.insertion sequentielle\n");
    printf("R.tri rapide\n");
    printf("F.fin:\n");
    printf("=====================\n");
    printf("\n\n");
    printf("faites votre choix(S,I,R,F):\n");
    scanf(" %c",&choix);
    if(choix=tolower(choix))
      choix=toupper(choix);

    switch(choix){
  case 'S':
      printf("donner le nombre d'element du tableau:\n");
      scanf("%d",&n);
      saisie(t,n);
      tri_selec(t,n);
      affichage(t,n);
      break;
  case 'I':
      printf("donner le nombre d'element du tableau");
      scanf("%d",&n);
      saisie(t,n);
      tri_insertion(t,n);
      affichage(t,n);
      break;
  case 'R':
      printf("donner le nombre d'element du tableau\n");
      scanf("%d",&n);
      saisie(t,n);
      tri_rapide(t,0,n);
      affichage(t,n);
      break;
  case 'F':
    break;
  default:
    printf("mauvais choix__ reprener\n");
    break;


    }
}
void menu_pricipal()
{
    TAB100 tp,t1,t2;
    int taille,x,n,m;
    int choix;
    while(choix!=3){
        printf("MENU PRINCIPAL\n");
        printf("=================\n");
        printf("1.recherche_insertion_fusion\n");
        printf("2.algorithmes de tri\n");
        printf("3.fin\n");
        printf("===================\n");
        printf("votre choix svp(1_2_3)\n");
        scanf("%d",&choix);
        printf("\n");
        switch(choix)
        {
        case 1:
            sous_menu1(tp,taille,x,t1,t2,m,n);
            break;
        case 2:
            sous_menu2(tp,taille);
            break;
        case 3:
            printf("\n\n AU REVOIR...");
            break;
        default:
            printf("mauvais choix_ reprenez svp\n");
            break;
        }
    }
}

#endif // UTILITAIRES_H_INCLUDED



