#ifndef ALGORITHMES_H_INCLUDED
#define ALGORITHMES_H_INCLUDED

#define MAX 100

typedef int TAB100[MAX];

bool recherche(TAB100 t, int n, int X)
{
   bool trouve=false;
   int gche=0, drte=n-1, milieu;
   do
   {
      if(gche>drte)
         trouve=false;
      milieu=(gche+drte)/2;
      if(t[milieu]==X)
         trouve=true;
      else
         if(X<t[milieu])
            drte=milieu-1;
         else
            gche=milieu+1;
   }
   while(!trouve && (gche<=drte));
   return trouve;
}

void insertion(TAB100 t, int n, int X)
{
   int pos=0,i;
   while(pos<n && X>t[pos])
      pos++;
   for(i=n-1;i>=pos-1;i--)
      t[i+1]=t[i];
   t[pos]=X;
}

void fusion(TAB100 t1, int n1, TAB100 t2, int n2)
{
   int i,v=0;
   for(i=0;i<n2;i++)
   {
      insertion(t1,n1+v,t2[i]);
      v++;
   }
}

void Selection(TAB100 t, int n)
{
   int i,j,aux,imin;
   for(i=0;i<=n-2;i++)
   {
      j=i+1;imin=i;
      do
      {
         if(t[imin]>t[j])
            imin=j;
            j++;
      }
      while(j<=n-1);
      aux=t[i];
      t[i]=t[j];
      t[j]=aux;
   }
}

void Insertion(TAB100 t,int n)
{
   int i,j,nbr;
   for(i=1;i<=n-1;i++)
   {
      nbr=t[i];
      for(j=i;j>0 && nbr<t[j-1];j--)
      {
         t[j]=t[j-1];
      }
      t[j]=nbr;
   }
}

void triRapide(TAB100 t,int db,int fn)
{
      int i,j,aux,vp,ml;
   i=db;j=fn;
   ml=(db+fn)/2;
   vp=t[ml];
   do
   {
   while(t[i]<vp)i++;
      while(t[j]>vp)j--;
      if(i<=j)
      {
         aux=t[i];
         t[i]=t[j];
         t[j]=aux;
         i++;j--;
      }
   }
   while(i<j);
   if(db<j){triRapide(t,db,j);}
   if(i<fn){triRapide(t,i,fn);}
}

#endif // ALGORITHMES_H_INCLUDED