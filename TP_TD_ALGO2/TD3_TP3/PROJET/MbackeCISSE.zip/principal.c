#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <stdbool.h>

#include "algorithmes.h"
#include "utilitaires.h"

#define MAX 100

typedef int TAB100[MAX];

int main()
{

   int choix, n, X, n1, n2, j;
   TAB100 t; TAB100 t1; TAB100 t2;
   char choix1; char choix2;

 do
 {
   menup();
   printf("VOTRE CHOIX SVP (1/2/3):");
   scanf("%d",&choix);
   printf("\n");
      if (choix==1)
         {
            sousMenu1 ();
            printf("\nFAITE VOTRE CHOIX [R(r)/I(i)/U(u)/F(f)]:");
            scanf("%s",&choix1);
            if(choix1=='R' || choix1=='r' || choix1=='I' || choix1=='i')
            {
            printf("ENTREZ LE NOMBRE D'ELEMENTS DU TABLEAU :");
            scanf("%d",&n);
            saisie(t,n);
            triRapide(t,0,n-1);
            affiche(t,n);
            printf("\n");
            }
            switch (choix1)
               {
               case ('r') :
               case ('R') :
                  {
                     printf("\nRECHERCHE D'UN ELEMENT DANS LE TABLEAU :\n");
                     printf("-----------------------------------------\n");
                     printf("DONNEZ L'ENTIER A RECHERCHER :");
                     scanf("%d",&X);
                     printf("-----------------------------------\n");
                     if(recherche(t,n,X)==true)
                        printf("L'ELEMENT FIGURE DANS LE TABLEAU");
                     else
                        printf("L'ELEMENT N'EST PAS DANS LE TABLEAU");
                        printf("\n");
                     break;
                  }
               case ('i') :
               case ('I') :
                  {
                     printf("\nINSERTION D'UN ELEMENT DANS UN TABLEAU :\n");
                     printf("-----------------------------------------\n");
                     printf("DONNEZ L'ENTIER A INSERER :");
                     scanf("%d",&X);
                     insertion(t,n,X);
                     affiche(t,n+1);
                     printf("\n");
                     break;
                  }
               case ('u') :
               case ('U') :
                  {
                     printf("ENTREZ LE NOMBRE D'ELEMENTS DU TABLEAU T1 :");
                     scanf("%d",&n1);
                     saisie(t1,n1);
                     triRapide(t1,0,n1-1);
                     affiche(t1,n1);
                     printf("\n");
                     printf("\nENTREZ LE NOMBRE D'ELEMENTS DU TABLEAU T2 :");
                     scanf("%d",&n2);
                     saisie(t2,n2);
                     triRapide(t2,0,n2-1);
                     affiche(t2,n2);
                     printf("\n");
                     printf("\nFUSION DE DEUX TABLEAUX :");
                     printf("\n--------------------------\n");
                     fusion(t1,n1,t2,n2);
                     affiche(t1,n1+n2);
                     printf("\n");
                     break;
                  }
               case ('f') :
               case ('F') :
                  {
                     printf("\nFin...");
                     printf("\n");
                     break;
                  }
               }
         }

      if (choix==2)
         {
            sousMenu2 ();
            printf("\nFAITE VOTRE CHOIX [S(s)/I(i)/R(r)/F(f)]:");
            scanf("%s",&choix2);
            if(choix2=='S'||choix2=='s'||choix2=='I'||choix2=='i'||choix2=='R'||choix2=='r')
            {
            printf("ENTREZ LE NOMBRE D'ELEMENTS DU TABLEAU :");
            scanf("%d",&n);
            saisie(t,n);
            affiche(t,n);
            printf("\n");
            }
            switch (choix2)
               {
               case ('s') :
               case ('S') :
                  {
                     printf("\nTRI PAR SELECTION :");
                     printf("\n--------------------\n");
                     Selection(t,n);
                     affiche(t,n);
                     printf("\n");
                     break;
                  }
               case ('i') :
               case ('I') :
                  {
                     printf("\nINSERTION SEQUENTIELLE :");
                     printf("\n-------------------------\n");
                     Insertion(t,n);
                     affiche(t,n);
                     printf("\n");
                     break;
                  }
               case ('r') :
               case ('R') :
                  {
                     printf("\nTRI RAPIDE :");
                     printf("\n-------------\n");
                     triRapide(t,0,n-1);
                     affiche(t,n);
                     printf("\n");
                     break;
                  }
               case ('f') :
               case ('F') :
                  {
                     printf("\n");
                     printf("\nFin...");
                     printf("\n");
                     break;
                  }
               }
         }
 }
 while(choix!=3);
  if (choix==3)
    {
        for(j=0;j<=7;j++)
        {
            sleep(1000);
            printf("\n");
        }
      printf("AU REVOIR...\n");
    }
 return 0;
}