#ifndef UTILITAIRES_H_INCLUDED
#define UTILITAIRES_H_INCLUDED

#define MAX 100

typedef int TAB100[MAX];

void menup()
{
   printf("\n    MENU PRINCIPAL\n");
   printf("   ================\n");
   printf("1.Recherche-Insertion-Fusion\n");
   printf("2.Algorithmes de tris\n");
   printf("3.Fin\n");
   printf("   ================\n");
}

void sousMenu1 ()
{
   printf("\nRecherche-Insertion-Fusion\n");
   printf("=========================\n");
   printf("R.Recherche dichotomique\n");
   printf("I.Insertion d'un element\n");
   printf("U.Fusion de deux tableaux\n");
   printf("F.Fin.\n");
   printf("========================\n");
}

void sousMenu2 ()
{
   printf("\nAgorithmes de tris\n");
   printf("===================\n");
   printf("S.Tri par selection\n");
   printf("I.Insertion sequentielle\n");
   printf("R.Tri rapide\n");
   printf("F.Fin.\n");
   printf("===================\n");

}

void permuter(int* x, int* y)
{
   int aux=*x;
   *x=*y;
   *y=aux;
}

void saisie(TAB100 t,int n)
{
   int i;
   for(i=0;i<n;i++)
   {
      printf("t[%d]=",i);
      scanf("%d",&t[i]);
   }
}

void affiche(TAB100 t,int n)
{
   if(n>0)
   {
      affiche(t,n-1);
      printf("%d    ",t[n-1]);
   }
}

#endif // UTILITAIRES_H_INCLUDED