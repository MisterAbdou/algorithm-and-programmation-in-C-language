#include <stdio.h>
#include <stdlib.h>
#include "utilitaires.h"
#include "algorithmes.h"

int main()
{
    int choix, choix2, n, x;
    char choix1;
    TAB100 T1, T2;

    do {
        menup();
        scanf("%d", &choix);
        switch (choix)
        {
            case 1:
                sousMenu1();
                scanf("%s", &choix1);
                switch (choix1)
                {
                    case 'R':
                        case 'r':
                        printf("RECHERCHE DICHOTOMIQUE\n");
                        printf("----------------------------\n");
						printf("ENTRER LE NOMBRE D'ELEMENTS : \n");
                        scanf("%d", &n);
                        saisie(T1, n);
                        triRapide(T1,n);
                        affichage(T1, n);
                        printf("\n");
                        printf("ENTRER L'ELEMENT A RECHERCHER : \n");
                        scanf("%d", &x);
                        recherche(T1, n, x);
                        printf("\n");
                        break;
                    case 'I':
                        case 'i':
                        printf("ENTRER LE NOMBRE D'ELEMENTS : \n");
                        scanf("%d", &n);
                        saisie(T1, n);
                        triRapide(T1,n);
                        affichage(T1, n);
                        printf("\n");
                        printf("INSERTION D'UN ELEMENT DANS LE TABLEAU\n");
                        printf("----------------------------------\n");
                        printf("ENTRER L'ELEMENT A INS�RER: \n");
                        scanf("%d", &x);
                        insertX(T1, x, n);
                        affichage(T1, n+1);
                        printf("\n");
                        break;
                    case 'U':
                        case 'u':
                        printf("ENTRER LE NOMBRE D'ELEMENTS DU PREMIER TABLEAU : ");
                        scanf("%d", &n);
                        saisie(T1, n);
                        printf("ENTRER LE NOMBRE D'ELEMENTS DU DEUXIEME TABLEAU: ");
                        scanf("%d", &n);
                        saisie(T2, n);
                        fusionTableaux(T1, n, T2, n);
                        affichage(T1,n+n);
                        printf("\n");
                        triRapide(T1,n+n);
                        printf("\n");
                        break;
                        case 'F':
                            case 'f':
						printf("Fin.\n");
						break;
                    default:
                        printf("Choix invalide!\n");
                        break;
                }
                break;
            case 2:
                sousMenu2();
                scanf("%s", &choix2);
                switch (choix2)
                {
                    case 'S':
                    	case 's':
                        printf("ENTRER LE NOMBRE D'ELEMENTS : ");
                        scanf("%d", &n);
                        saisie(T1, n);
                        selection(T1, n);
                        affichage(T1, n);
                        printf("\n");
                        break;
                    case 'I':
                    	case 'i':
                        printf("ENTRER LE NOMBRE D'ELEMENTS : ");
                        scanf("%d", &n);
                        saisie(T1, n);
                        insertionSequentielle(T1, n);
                        affichage(T1, n);
                        printf("\n");
                        break;
                    case 'R':
                    	case 'r':
                        printf("ENTRER LE NOMBRE D'ELEMENTS : \n");
                        scanf("%d", &n);
                        saisie(T1, n);
                        triRapide(T1, n);
                        affichage(T1, n);
                        printf("\n");
                        break;
                        case 'F':
						printf("Fin.\n");
						break;
                    default:
                        printf("Choix invalide!\n");
                        break;
                }
                break;
            case 3:
                printf("Au revoir!\n");
                break;
            default:
                printf("Choix invalide!\n");
                break;
        }
    } while (choix != 3);
}
