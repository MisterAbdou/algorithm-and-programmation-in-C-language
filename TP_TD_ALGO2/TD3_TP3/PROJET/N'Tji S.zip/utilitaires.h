#ifndef UTILITAIRES_H_INCLUDED
#define UTILITAIRES_H_INCLUDED
#endif // UTILITAIRES_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

typedef int TAB100[100];
void menup()
{
    printf("   Menu principal: \n");
    printf("  ================\n");
    printf("1.Recherche-Insertion-Fusion\n");
    printf("2.Algorithmes de tris\n");
    printf("3.Fin\n");
    printf("  ================\n");
    printf("VOTRE CHOIX SVP(1/2/3): ");
  
}

void sousMenu1()
{   printf("Recherche-Insertion-Fusion\n");
    printf("==========================\n");
    printf("R.Recherche dichotomique\n");
    printf("I.Insertion d'un element\n");
    printf("U.Fusion de deux tableaux\n");
    printf("F.Fin.\n");
    printf("==========================\n\n\n");
    printf("FAITES VOTRE CHOIX [R(r)/I(i)/U(u)/F(f)] : ");
    
}

void sousMenu2()
{   printf("\n\n");
	printf("Algorithmes de tris\n");
	printf("====================\n");
    printf("S.Tri par selection\n");
    printf("I.Insertion sequentielle\n");
    printf("R.Tri rapide\n");
    printf("F.Fin.\n");
   	printf("====================\n");
   	printf("\n\n");
    printf("VOTRE CHOIX [S(s)/I(i)/R(r)/F(f)] : ");
}

void saisie(TAB100 T, int n)
{
    int i;
    printf("Entrer %d elements \n", n);
    for (i = 0; i < n; i++)
    {
        printf("T[%d] = ", i);
        scanf("%d", &T[i]);
    }
}

void permutation(TAB100 T, int i, int j)
{
    int temp;
    temp = T[i];
    T[i] = T[j];
    T[j] = temp;
}

void affichage(TAB100 T, int n)
{
    int i;
    printf("Les �l�ments du tableau sont: \n");
    for (i = 0; i < n; i++)
    {
        printf(" %d ",T[i]);
    }
}
void echange(int *a, int *b) 
{ 
    int t = *a; 
    *a = *b; 
    *b = t; 
} 

