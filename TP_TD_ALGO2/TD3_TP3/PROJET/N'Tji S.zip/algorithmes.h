#ifndef ALGORITHMES_H_INCLUDED
#define ALGORITHMES_H_INCLUDED
#endif // ALGORITHMES_H_INCLUDED
#include <stdio.h>
typedef int TAB100[100];
void recherche(TAB100 T, int n, int x)
{
    int i, j, m;
    i = 0;
    j = n-1;
    while(i<=j)
    {
        m = (i + j) / 2;
        if (T[m] == x)
        {
            printf("ELEMENT TROUVE A L'INDICE %d\n", m);
            printf("L'ELEMENT RECHERCHE EST T[%d]= %d\n",m, T[m]);
            return;
        }
        else
        {
            if (T[m] < x)
                i = m + 1;
            else
                j = m - 1;
        }
    }
    printf("ELEMENT NON TROUVE\n");
}
void insertX (TAB100 T , int x, int n )
{
    int pos = 0, j;
    /* LE TABLEAU �TANT TRI� DANS L'ORDRE CROISSANT, ON LE PARCOURT JUSQU'� TROUVER L'�L�MENT PLUS PETIT QUE x � INS�RER */
    while (pos <n && x>T[pos])
        pos++; /* ON INCR�MENTE TANT QUE x EST PLUS GRAND */
    /* D�CALAGE � DROITE (LE TABLEAU �TANT ORDONN�) */
    for (j = n - 1; j >= pos; j--)
        T[j + 1] = T[j];
    /* INSERTION DE L'�L�MENT */
    T[pos] = x;

 }
void fusionTableaux (TAB100 T1, int n1, TAB100 T2, int n2)
{
    int pos1 = 0, pos2 = 0, posF = 0, x,i;
    TAB100 T;
    while (pos1 < n1 && pos2 < n2)
    {
        if (T1[pos1] <= T2[pos2])
        {
            x = T1[pos1];
            pos1++;
        }
        else
        {
            x = T2[pos2];
            pos2++;
        }
        insertX(T, x, posF);
        posF++;
    }
    /* ON INS�RE LES �L�MENTS RESTANTS DU PREMIER TABLEAU */
    for (i = pos1; i < n1; i++)
    {
        x = T1[i];
        insertX(T, x, posF);
        posF++;
    }
    /* ON INS�RE LES �L�MENTS RESTANTS DU SECOND TABLEAU */
    for (i = pos2; i < n2; i++)
    {
        x = T2[i];
        insertX(T, x, posF);
        posF++;
    }
    /* COPIE DU TABLEAU FUSIONN� VERS T1 */
    for (i = 0; i < posF; i++)
        T1[i] = T[i];
}
void selection(TAB100 T, int n)
{
    int i, j, min;
    for (i = 0; i < n - 1; i++)
    {
        min = i;
        for (j = i + 1; j < n; j++)
        {
            if (T[j] < T[min])
                min = j;
        }
        permutation(T, i, min);
    }
}

void insertionSequentielle(TAB100 T, int n)
{
    int i, j, x;
    for (i = 1; i < n; i++)
    {
        x = T[i];
        j = i - 1;
        while (j >= 0 && T[j] > x)
        {
            T[j+1] = T[j];
            j--;
        }
        T[j+1] = x;
    }
}

void triRapide(TAB100 T, int n)
{
    int i, j, x;
    if (n < 2)
        return;
    x = T[n/2];
    i = 0;
    j = n - 1;
    while (i <= j)
    {
        while (T[i] < x)
            i++;
        while (T[j] > x)
            j--;
        if (i <= j)
        {
            permutation(T, i, j);
            i++;
            j--;
        }
    }
    triRapide(T, j+1);
    triRapide(T+i, n-i);
}


