#ifndef ALGORITHMES_H_INCLUDED
#define ALGORITHMES_H_INCLUDED
#include<string.h>
#define NMAX 100
typedef int TAB100 [NMAX];

int partition(TAB100 t,int deb,int fin)
{
    int pivot,i,j;
    pivot=t[(deb+fin)/2];
    i=deb;
    j=fin;

    while(t[i]<pivot)
    {
        i++;
    }
        while(pivot<t[j])
        {
            j--;
        }
        if(i<j)
        {
            Permuter(t,i,j);

        }
        return j;
}

void Tri_rapide(TAB100 t,int deb,int fin )
{
    int pivot;
    if(deb<fin)
    {
        pivot=partition(t,deb,fin);
        Tri_rapide(t,deb,pivot-1);
        Tri_rapide(t,pivot+1,fin);
    }
}

void insertion(TAB100 t,int x,int *n)
{
    int pos;
    int i;
    pos=0;
    while(pos<*n&&x>t[pos])
    {
        pos++;
    }
    for(i=*n-1;i>=pos-1;i--)
    {
        t[i+1]=t[i];
    }
    t[pos]=x;
    (*n)++;

}




void fusion(TAB100 t1,TAB100 t2,int *n,int m)
{
    int i,x;
    for(i=0;i<m;i++)
    {
        x=t2[i];
        insertion(t1,x,n);
    }
}


void selection(TAB100 t,int n)
{
    int i;
    int j;
    int imin;
   for (i=0;i<n;i++)
   {
    imin=i;
       for (j=i+1;j<n;j++)
        {
           if (t[j]<t[imin])
               imin=j;
        }

        Permuter(t,i,imin);
    }
}


void insertion_seq(TAB100 t,int n)
{
  int temp,j;
  int i;
  for(i=1;i<n;i++)
  {
      temp=t[i];
      j=i;

      while(j>0&&t[j-1]>temp)
      {
          t[j]=t[j-1];
        j--;
      }

      t[j]=temp;
  }
}
int Recherche(TAB100 t,int n,int x)
{
    int debut=0;
    int fin=n-1;
    int m;
    while(debut<=fin){
           m=(debut+fin)/2;
           if(t[m]==x){
               return m;
               }
             if(t[m]>x)
              {
                fin=m-1;
              }
             if(t[m]<x)
              {
                debut=m+1;
              }
    }
   return -1;
}


#endif // ALGORITHMES_H_INCLUDED
