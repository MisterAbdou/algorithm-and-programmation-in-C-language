#ifndef UTILITAIRES_H_INCLUDED
#define UTILITAIRES_H_INCLUDED
#define NMAX 100
typedef int TAB100 [NMAX];

int menup()
{
    int i;
    printf("\n    MENU PRINCIPAL    \n");
    printf("==============================");
    printf("\n 1.Recherche-Insertion-Fusion \n");
    printf("\n 2.Algorithme de tris \n");
    printf(" \n 3.Fin \n");
    printf("\n ========================\n ");
    printf("VOTRE CHOIX SVP : ");
    scanf("%d",&i);
    printf("\n");
    return i;
}

void Saisie(TAB100 t,int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("t[%d]=",i);
        scanf("%d",&t[i]);
    }
}

void Affichage(TAB100 t,int n)
{
    int i;
    for(i=0;i<n;i++){

        printf("%d\t",t[i]);

        }
}

void Permuter( TAB100 t,int i,int j)
{
    int temp;
    temp=t[i];
    t[i]=t[j];
    t[j]=temp;
}



char sousmenue1()
{
    char c;
    printf("================================\n");
    printf("R.Recherche dichotomique\n");
    printf("I.Insertion d'un element \n");
    printf("U.Fusion de deux tableaux \n");
    printf("F.Fin \n");
    printf("===================================");
    printf("\n\n");
    printf("VOTRE CHOIX SVP [R(r)/I(i)/U(u)/F(f)] :");
    do {
    scanf("%c",&c);
    }while(c!='R' && c!='r' && c!='I' && c!='i' && c!='U' && c!='u' && c!='F' && c!='f');
    return c;
}

char sousmenue2()
{
    char m;
    printf("================================\n");
    printf("S.Tri par selection  \n");
    printf("I.Insertion sequentielle  \n");
    printf("R.Tri rapides    \n");
    printf("F.Fin \n");
    printf("===================================");
    printf("\n\n");
    printf("VOTRE CHOIX SVP [S(s)/I(i)/R(r)/F(f)] :");
    do {
    scanf("%c",&m);
    }while(m!='S' && m!='s' && m!='I' && m!='i' && m!='R' && m!='r' && m!='F' && m!='f');
    return m;

}


#endif // UTILITAIRES_H_INCLUDED

