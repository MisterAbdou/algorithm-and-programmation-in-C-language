#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#ifndef PRINCIPAL_C_INCLUDED
#define PRINCIPAL_C_INCLUDED
#include"utilitaires.h"
#include"algorithmes.h"
#define NMAX 100
typedef int TAB100 [NMAX];

int main()
{
    TAB100 t;
    TAB100 t1;
    TAB100 t2;
     int s;
    int z;
    char l;
    int n;
    int k;
    int w;
    char m;
    int g;
    do{
        z=menup();
        switch(z){
    case 1:
        printf("Recherche-Insertion-Fusion\n");
        l=sousmenue1();{
        if(l=='R' || l=='r'){

            printf("\n======================\n");
            printf("**RECHERCHE DICHOTOMIQUE**\n");
            printf("\n==========================\n");
            printf("\n donner la taille du tableau : ");
            scanf("%d",&n);
            Saisie(t,n);
            printf("\n\n");
            printf("TABLEAU AVANT TRI :\n");
            Affichage(t,n);
            printf("\n TABLEAU APRES TRI :\n");
            selection(t,n);
            Affichage(t,n);
            printf("\n donner l'element a chercher : ");
            scanf("%d",&g);
            k= Recherche(t,n,g);
            if(k==-1)
            {
                printf("\n l'element rechercher n'est pas dans le tableau !!!!\n");
            }
            else
            {
                printf("L'ENTIER SE TROUVE A LA POSITION : t[%d]",k);
            }
        }

        if(l=='I' || l=='i')
        {
            printf(" \n ***INSERTION D'UN ELEMENT*** \n");
            printf("\n=======================\n");
            printf("\n donner la taille du tableau : ");
            scanf("%d",&n);
            Saisie(t,n);
            printf("\n\n");
            printf("TABLEAU AVANT TRI :\n");
            Affichage(t,n);
            printf("\n TABLEAU APRES TRI :\n");
            selection(t,n);
            Affichage(t,n);
            printf(" \n Donner l'element a inserer: ");
            scanf("%d",&w);
            insertion(t,w,&n);
            printf("*** TABLEAU APRES INSERTION ***\n");
            Affichage(t,n);
        }

        if(l=='U' || l=='u')
        {
            printf("*** FUSION *** \n");
            printf("\n donner la taille du tableau 1: ");
            scanf("%d",&n);
            Saisie(t1,n);
            printf("\n\n");
            printf("TABLEAU AVANT TRI :\n");
            Affichage(t1,n);
            printf("\n TABLEAU APRES TRI :\n");
            selection(t1,n);
            Affichage(t1,n);
            printf("\n donner la taille du tableau : ");
            scanf("%d",&s);
            Saisie(t2,s);
            printf("\n\n");
            printf("TABLEAU AVANT TRI :\n");
            Affichage(t2,s);
            printf("\n TABLEAU APRES TRI :\n");
            selection(t2,s);
            Affichage(t2,s);
            printf("\n LA FUSION DONNE \n");
            fusion(t1,t2,&n,s);
            Affichage(t1,n);

        }
        if(l=='F' || l=='f')
        {
            printf("*** FIN A LA PROCHAINE ***");
        }
}
        break;
    case 2:
        printf("**ALGORITHME DE TRI** \n");
        m=sousmenue2();{
            if(m=='S' || m=='s'){
                printf("***TRI PAR SELECTION***\n");
                printf("\n=====================\n");
                printf("\n donner la taille du tableau :\n");
                scanf("%d",&n);
                Saisie(t,n);
                printf("\n\n");
                printf("TABLEAU AVANT TRI :\n");
                Affichage(t,n);
                printf("\n TABLEAU APRES TRI :\n");
                selection(t,n);
                Affichage(t,n);

            }

            if(m=='I' || m=='i')
            {
                printf("***INSERTION SEQUENTIELLE***\n");
                printf("\n=====================\n");
                printf("\n donner la taille du tableau :\n");
                scanf("%d",&n);
                Saisie(t,n);
                printf("\n\n");
                printf("TABLEAU AVANT TRI :\n");
                Affichage(t,n);
                printf("\n TABLEAU APRES TRI :\n");
                insertion_seq(t,n);
                Affichage(t,n);

            }

            if(m=='R' || m=='r')
            {
                printf("***TRI RAPIDE OU QUICK-SORT***\n");
                printf("\n=========================\n");
                printf("\n donner la taille du tableau :\n");
                scanf("%d",&n);
                Saisie(t,n);
                printf("\n\n");
                printf("TABLEAU AVANT TRI :\n");
                Affichage(t,n);
                printf("\n TABLEAU APRES TRI :\n");
                selection(t,n);
                Affichage(t,n);

            }

            if(m=='F' || m=='f')
            {
                printf("FIN A LA PROCHAINE !!!!!");
            }

        }
        break;
    case 3:
        printf("\n\n\n\n\n\n\n\n\n\n\n\n AU REVOIR... \n");
        break;
    default :
        printf("veuillez revoir votre choix svp !!!!!!!");
        break;

        }
    }while(z!=3);


}




#endif // PRINCIPAL_C_INCLUDED
